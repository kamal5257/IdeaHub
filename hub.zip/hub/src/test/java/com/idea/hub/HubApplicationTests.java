package com.idea.hub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HubApplicationTests {

	@Test
	void contextLoads() {
	}

}
